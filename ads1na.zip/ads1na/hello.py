print("salve irmao forte abraço!!!")

print(7)

print(9.3)
print("7")

print(7 + 5)

print("7" + "5")

# abaixo eu começo a verificar os tipos de dados 

print("---------------")

print(type(7))

print(type(9.3))

print(type("ola mundo!"))
