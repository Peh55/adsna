nome = input("Escreva seu nome:")
idade = int(input("Escreva sua idade:"))
print("Seu nome é: ", nome, "\nSua idade é: ", idade)