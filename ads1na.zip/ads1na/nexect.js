num1 = 1 
num2 = input()

soma = num1 + num2

console.log(soma)