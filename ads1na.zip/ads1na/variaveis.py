#trabalhando com variaveis
nome = input("Digite seu nome: ")

print(f"Olá {nome}")